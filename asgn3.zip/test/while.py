a = 10
while a > 0:
	a = a - 1
	print a*a