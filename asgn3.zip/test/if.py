a = 100
if a < 200:
	c = 2000
	d = 200*10
	isEqual = (c==d)
	if isEqual==True:
		print "Hello"
	else:
		d = 1000
