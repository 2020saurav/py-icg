a = [1, 2, 3, 9, 7, 3]
for i in a:
	c = i * i + 3 / 2
for var in [1,3,6,7]:
	print var*var