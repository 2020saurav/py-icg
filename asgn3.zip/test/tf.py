True = 1
False = 0